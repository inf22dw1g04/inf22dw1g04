'use strict';

var sql = require('../dbconnect.js');

/**
 * Create Occurencia
 *
 * body Ocurrencias  (optional)
 * returns Ocurrencias
 **/
exports.createOcurrencia = function(body) {
  return new Promise(function(resolve, reject) {
    console.log(body);
    sql.query("INSERT INTO ocurrencia (num_faltas,  num_golos, num_cartao, minutos, substituicao, temporada_id, id_equipa, id_jogador, id_jogos) Values(?,?,?,?,?,?,?,?,?)", [body.num_faltas,  body.num_golos, body.num_cartao, body.minutos, body.substituicao, body.temporada_id, body.id_equipa, body.id_jogador, body.id_jogos], function (err, res) {
      if (err) {
        console.log(err);
        reject(err);
      }
      else {
        console.log(res.insertId);
        resolve(res.insertId);
      }
    });
  });
}

/**
 * Delete Ocurrencia
 *
 * id_ocurrencia Long 
 * no response value expected for this operation
 **/
exports.deleteOcurrencia = function(id_ocurrencia) {
  return new Promise(function(resolve, reject) {
    sql.query("DELETE FROM ocurrencia WHERE id = ?", [id_ocurrencia], function (err, res){
      if (err || !res.affectedRows) {
        console.log(err)
        console.log(res);
        reject();
      }
    }) 
  });
}


/**
 * Retrieve Ocurrencias
 *
 * returns List
 **/
exports.retrieveOcurrencia = function() {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM ocurrencia",  function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}


/**
 * Retrieve Ocurrencias by ID
 *
 * id_ocurrencia Long 
 * returns Ocurrencias
 **/
exports.retrieveOcurrenciaId = function(id_ocurrencia) {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM ocurrencia WHERE id = ?", [id_ocurrencia], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}


/**
 * Update Ocurrencia
 *
 * body Ocurrencias 
 * id_ocurrencia Long 
 * no response value expected for this operation
 **/
exports.updateOcurrencia = function(body,id_ocurrencia) {
  return new Promise(function(resolve, reject) {
    sql.query("UPDATE ocurrencia set num_faltas = ?,  num_golos = ?, num_cartao = ?, minutos = ?, substituicao = ?, temporada_id = ?, id_equipa = ?, id_jogador = ?, id_jogos = ? WHERE id = ?", [body.num_faltas,  body.num_golos, body.num_cartao, body.minutos, body.substituicao, body.temporada_id, body.id_equipa, body.id_jogador, body.id_jogos, id_ocurrencia], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(id);
      }
    }) 
  });
}
