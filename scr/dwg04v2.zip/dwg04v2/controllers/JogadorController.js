'use strict';

var utils = require('../utils/writer.js');
var JogadorController = require('../service/JogadorControllerService');

module.exports.pAtchJogadorById = function pAtchJogadorById (req, res, next, body, numero_do_jogador) {
  JogadorController.pAtchJogadorById(body, numero_do_jogador)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveJogador = function retrieveJogador (req, res, next) {
  JogadorController.retrieveJogador()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveJogadorEquipaId = function retrieveJogadorEquipaId (req, res, next, id_jogador) {
  JogadorController.retrieveJogadorEquipaId(id_jogador)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveJogadorId = function retrieveJogadorId (req, res, next, id_jogador) {
  JogadorController.retrieveJogadorId(id_jogador)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
