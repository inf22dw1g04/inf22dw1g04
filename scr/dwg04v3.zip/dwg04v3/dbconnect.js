'use strict';

const mysql = require('mysql');

const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  database: "temporada"
});

con.connect(function(err) {
  if (err) {
    console.log('Error on database connection. ');
    throw err;
}
console.log('Database connection active. ');
});

module.exports = con;