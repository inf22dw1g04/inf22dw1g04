'use strict';

const sql = require('../dbconnect.js');

/**
 * Create Jogo
 *
 * body Jogos  (optional)
 * returns Jogos
 **/
exports.createJogo = function(body) {
  return new Promise(function(resolve, reject) {
    sql.query("INSERT INTO equipa (resultado, tempora_id, equipa_id) Values(?, ?, ?)", [body.resultado, body.id_temporada, body.id_equipa], function (err, res) {
      if (err) {
        console.log(err);
        reject(err);
      }
      else {
        console.log(res.insertId);
        resolve(res.insertId);
      }
    });
  });
}


/**
 * Delete Jogos
 *
 * id_jogo Long 
 * no response value expected for this operation
 **/
exports.deleteJogos = function(id_jogo) {
  return new Promise(function(resolve, reject) {
    sql.query("DELETE FROM jogos WHERE id = ?", [id_jogo], function (err, res){
      if (err || !res.affectedRows) {
        console.log(err)
        console.log(res);
        reject();
      }
    }) 
  });
}


/**
 * Retrieve Jogos
 *
 * returns List
 **/
exports.retrieveJogos = function() {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM jogos",  function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}


/**
 * Retrieve Jogos by ID
 *
 * id_jogo Long 
 * returns Jogos
 **/
exports.retrieveJogosId = function(id_jogo) {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM jogos WHERE id = ?", [id_jogo], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}



/**
 * Update Jogos
 *
 * body Jogos 
 * id_jogo Long 
 * no response value expected for this operation
 **/
exports.updateJogos = function(body,id_jogo) {
  return new Promise(function(resolve, reject) {
    sql.query("UPDATE jogos set resultado = ?, tempora_id = ?, equipa_id = ? WHERE = id", [body.resultado, body.id_temporada, body.id_equipa, id_jogo], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(id);
      }
    }) 
  });
  }

