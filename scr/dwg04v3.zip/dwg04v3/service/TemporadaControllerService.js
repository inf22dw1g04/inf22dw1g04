'use strict';

const sql = require('../dbconnect.js');

/**
 * Create Temporada
 *
 * body Temporada  (optional)
 * returns Temporada
 **/
exports.createTemporada = function(body) {
  return new Promise(function(resolve, reject) {
    sql.query("INSERT INTO temporada (nome, equipa_id) Values(?, ?)", [body.nome_temporada, body.id_equipa], function (err, res) {
      if (err) {
        console.log(err);
        reject(err);
      }
      else {
        console.log(res.insertId);
        resolve(res.insertId);
      }
    });
  });
}


/**
 * Delete Temporada
 *
 * id_temporada Long 
 * no response value expected for this operation
 **/
exports.deleteTemporada = function(id_temporada) {
  return new Promise(function(resolve, reject) {
    sql.query("DELETE FROM temporada WHERE id = ?", [id_temporada], function (err, res){
      if (err || !res.affectedRows) {
        console.log(err)
        console.log(res);
        reject();
      }
    }) 
  });
}


/**
 * Retrieve Temporada
 *
 * returns List
 **/
exports.retrieveTemporada = function() {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM temporada",  function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}



/**
 * Retrieve Temporada by ID
 *
 * id_temporada Long 
 * returns Temporada
 **/
exports.retrieveTemporadaId = function(id_temporada) {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM temporada WHERE id = ?", [id_temporada], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}


/**
 * Update Temporada
 *
 * body Temporada 
 * id_temporada Long 
 * no response value expected for this operation
 **/
exports.updateTemporada = function(body,id_temporada) {
  return new Promise(function(resolve, reject) {
    sql.query("UPDATE temporada set nome = ?, equipa_id WHERE id = ?", [body.nome, body.id_equipa, id_temporada], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(id);
      }
    }) 
  });
  }


