'use strict';


/**
 * Update Numero Jogador
 *
 * body Jogador Update Jogador (optional)
 * numero_do_jogador Long Numero do Jogador
 * returns Jogador
 **/
exports.pAtchJogadorById = function(body,numero_do_jogador) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "nome_do_jogador" : "nome_do_jogador"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve Jogador
 *
 * returns List
 **/
exports.retrieveJogador = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "nome_do_jogador" : "nome_do_jogador"
}, {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "nome_do_jogador" : "nome_do_jogador"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve Jogador on Equipa
 *
 * id_jogador Long 
 * returns Equipa
 **/
exports.retrieveJogadorEquipaId = function(id_jogador) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "nome_equipa" : "nome_equipa",
  "id_equipa" : 0
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve Jogador by ID
 *
 * id_jogador Long 
 * returns Jogador
 **/
exports.retrieveJogadorId = function(id_jogador) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "nome_do_jogador" : "nome_do_jogador"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

