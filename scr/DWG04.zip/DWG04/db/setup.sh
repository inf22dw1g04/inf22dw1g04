#!/bin/bash
set -e
service mysql start 
mysql < /DWG04/db/temporada.sql
service mysql stop 