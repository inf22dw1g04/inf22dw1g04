'use strict';

const sql = require('../dbconnect.js');

/**
 * Create Equipa
 *
 * body Equipa  (optional)
 * returns Equipa
 **/
exports.createEquipa = function(body) {
  return new Promise(function(resolve, reject) {
    sql.query("INSERT INTO equipa (nome) Values(?)", [body.nome_equipa], function (err, res) {
      if (err) {
        console.log(err);
        reject(err);
      }
      else {
        console.log(res.insertId);
        resolve(res.insertId);
      }
    });
  });
}


/**
 * Delete Equipa
 *
 * id_equipa Long 
 * no response value expected for this operation
 **/
exports.deleteEquipa = function(id_equipa) {
  return new Promise(function(resolve, reject) {
    sql.query("DELETE FROM equipa WHERE id = ?", [id_equipa], function (err, res){
      if (err || !res.affectedRows) {
        console.log(err)
        console.log(res);
        reject();
      }
    }) 
  });
}


/**
 * Retrieve Equipa
 *
 * returns List
 **/
exports.retrieveEquipa = function() {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM equipa",  function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}


/**
 * Retrieve Equipa by ID
 *
 * id_equipa Long 
 * returns Equipa
 **/
exports.retrieveEquipaId = function(id_equipa) {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM equipa WHERE id = ?", [id_equipa], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}


/**
 * Retrieve Equipa on temporada
 *
 * id_equipa Long 
 * returns Temporada
 **/
exports.retrieveEquipaTemporadaId = function(id_equipa) {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM temporada WHERE id = ?", [id_equipa], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}


/**
 * Update Equipa
 *
 * body Equipa 
 * id_equipa Long 
 * no response value expected for this operation
 **/
exports.updateEquipa = function(body,id_equipa) {
  return new Promise(function(resolve, reject) {
    sql.query("UPDATE equipa set nome = ? WHERE id = ?", [body.nome_equipa, id_equipa], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(id);
      }
    }) 
  });
  }
