'use strict';

var utils = require('../utils/writer.js');
var EstatisticasController = require('../service/EstatisticasControllerService');

module.exports.createEstatisticas = function createEstatisticas (req, res, next, body) {
  EstatisticasController.createEstatisticas(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteEstatisticas = function deleteEstatisticas (req, res, next, id_estatistica) {
  EstatisticasController.deleteEstatisticas(id_estatistica)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveEstatistica = function retrieveEstatistica (req, res, next) {
  EstatisticasController.retrieveEstatistica()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveEstatisticaId = function retrieveEstatisticaId (req, res, next, id_estatistica) {
  EstatisticasController.retrieveEstatisticaId(id_estatistica)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateEstatisticas = function updateEstatisticas (req, res, next, body, id_estatistica) {
  EstatisticasController.updateEstatisticas(body, id_estatistica)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .then(OcurrenciasController.retrieveOcurrencia)
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
