'use strict';

const sql = require('../dbconnect.js');

/**
 * Create Jogador
 *
 * body Jogador  (optional)
 * returns Jogador
 **/
exports.createJogador = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "id_temporada" : 1,
  "nome_do_jogador" : "nome_do_jogador",
  "id_equipa" : 5,
  "id_estatistica" : 5
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete Jogador
 *
 * id_jogador Long 
 * no response value expected for this operation
 **/
exports.deleteJogador = function(id_jogador) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update Numero Jogador
 *
 * body Jogador Update Jogador (optional)
 * numero_do_jogador Long Numero do Jogador
 * returns Jogador
 **/
exports.pAtchJogadorById = function(body,numero_do_jogador) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "id_temporada" : 1,
  "nome_do_jogador" : "nome_do_jogador",
  "id_equipa" : 5,
  "id_estatistica" : 5
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve Jogador
 *
 * returns List
 **/
exports.retrieveJogador = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "id_temporada" : 1,
  "nome_do_jogador" : "nome_do_jogador",
  "id_equipa" : 5,
  "id_estatistica" : 5
}, {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "id_temporada" : 1,
  "nome_do_jogador" : "nome_do_jogador",
  "id_equipa" : 5,
  "id_estatistica" : 5
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve Jogador on Equipa
 *
 * id_jogador Long 
 * returns Equipa
 **/
exports.retrieveJogadorEquipaId = function(id_jogador) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "nome_equipa" : "nome_equipa",
  "id_equipa" : 0
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Retrieve Jogador by ID
 *
 * id_jogador Long 
 * returns Jogador
 **/
exports.retrieveJogadorId = function(id_jogador) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "numero_do_jogador" : 6,
  "id_jogador" : 0,
  "id_temporada" : 1,
  "nome_do_jogador" : "nome_do_jogador",
  "id_equipa" : 5,
  "id_estatistica" : 5
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update Jogador
 *
 * body Jogador 
 * id_jogador Long 
 * no response value expected for this operation
 **/
exports.updateJogador = function(body,id_jogador) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

