'use strict';

const sql = require('../dbconnect.js');

/**
 * Create Estatisticas
 *
 * body Estatisticas  (optional)
 * returns Estatisticas
 **/
exports.createEstatisticas = function(body) {
  return new Promise(function(resolve, reject) {
    sql.query("INSERT INTO estatisticas (golos_marcados,  golos_sofridos, faltas_sofridas, faltas_feitas, temporada_id, id_equipa) Values(?,?,?,?,?,?)", [body.golos_marcados,  body.golos_sofridos, body.faltas_sofridas, body.faltas_feitas, body.temporada_id, body.id_equipa], function (err, res) {
      if (err) {
        console.log(err);
        reject(err);
      }
      else {
        console.log(res.insertId);
        resolve(res.insertId);
      }
    });
  });
}


/**
 * Delete Estatisticas
 *
 * id_estatistica Long 
 * no response value expected for this operation
 **/
exports.deleteEstatisticas = function(id_estatistica) {
  return new Promise(function(resolve, reject) {
    sql.query("DELETE FROM estatisticas WHERE id = ?", [id_estatistica], function (err, res){
      if (err || !res.affectedRows) {
        console.log(err)
        console.log(res);
        reject();
      }
    }) 
  });
}


/**
 * Retrieve Estatistica
 *
 * returns List
 **/
exports.retrieveEstatistica = function() {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM estatisticas",  function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}



/**
 * Retrieve Estatisticas by ID
 *
 * id_estatistica Long 
 * returns Estatisticas
 **/
exports.retrieveEstatisticaId = function(id_estatistica) {
  return new Promise(function(resolve, reject) {
    sql.query("SELECT * FROM estatisticas WHERE id = ?", [id_estatistica], function (err, res){
      if (err) {
        console.log(err)
        reject(err);
      }
      else {
        console.log(res);
        resolve(res[0]);
      }
    }) 
  });
}

/**
 * Update Estatisticas
 *
 * body Estatisticas 
 * id_estatistica Long 
 * no response value expected for this operation
 **/
exports.updateEstatisticas = function(body,id_estatistica) {
return new Promise(function(resolve, reject) {
  sql.query("UPDATE estatisticas set golos_marcados = ?,  golos_sofridos = ?, faltas_sofridas = ?, faltas_feitas = ?, temporada_id = ?, id_equipa = ? WHERE id = ?", [body.golos_marcados,  body.golos_sofridos, body.faltas_sofridas, body.faltas_feitas, body.temporada_id, body.id_equipa, id_estatistica], function (err, res){
    if (err) {
      console.log(err)
      reject(err);
    }
    else {
      console.log(res);
      resolve(id);
    }
  }) 
});
}


