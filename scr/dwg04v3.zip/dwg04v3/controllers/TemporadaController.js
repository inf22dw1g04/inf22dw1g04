'use strict';

var utils = require('../utils/writer.js');
var TemporadaController = require('../service/TemporadaControllerService');

module.exports.createTemporada = function createTemporada (req, res, next, body) {
  TemporadaController.createTemporada(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteTemporada = function deleteTemporada (req, res, next, id_temporada) {
  TemporadaController.deleteTemporada(id_temporada)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveTemporada = function retrieveTemporada (req, res, next) {
  TemporadaController.retrieveTemporada()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveTemporadaId = function retrieveTemporadaId (req, res, next, id_temporada) {
  TemporadaController.retrieveTemporadaId(id_temporada)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateTemporada = function updateTemporada (req, res, next, body, id_temporada) {
  TemporadaController.updateTemporada(body, id_temporada)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .then(OcurrenciasController.retrieveOcurrencia)
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
