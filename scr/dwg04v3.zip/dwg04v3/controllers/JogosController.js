'use strict';

var utils = require('../utils/writer.js');
var JogosController = require('../service/JogosControllerService');

module.exports.createJogo = function createJogo (req, res, next, body) {
  JogosController.createJogo(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.deleteJogos = function deleteJogos (req, res, next, id_jogo) {
  JogosController.deleteJogos(id_jogo)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveJogos = function retrieveJogos (req, res, next) {
  JogosController.retrieveJogos()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.retrieveJogosId = function retrieveJogosId (req, res, next, id_jogo) {
  JogosController.retrieveJogosId(id_jogo)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.updateJogos = function updateJogos (req, res, next, body, id_jogo) {
  JogosController.updateJogos(body, id_jogo)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .then(OcurrenciasController.retrieveOcurrencia)
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
